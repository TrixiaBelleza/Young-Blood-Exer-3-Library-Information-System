import person.User;
import lib.Library;
import lib.Books;
import java.util.Scanner;


public class Main{
  static int noOfUsers=0;
  static User[] users = new User[10]; // array of users
  static User avatar;
public static void main(String[] args){
  int i=0, option = 0;
  Library mainLib = new Library("Main Library"); // instance of library

  signUp(mainLib);
  while(option!=5){ // while the user does not want to exit
    option = mainMenu();
    switch(option){
      case 01: signUp(mainLib); break;
      case 02: avatar.userMenu(); break;
      case 03: mainLib.libMenu(); break;
      case 04: changeUser();break;
      case 05: System.out.println("Exit"); mainLib.saveLibrary(); break;
      }
    }
  }

  // methods
  public static int mainMenu(){
    int option = 0;
    Scanner sc = new Scanner(System.in);
    // implementation of menu system
    System.out.println("Main Library System");
    System.out.println("  [1] Sign Up");
    System.out.println("  [2] User");
    System.out.println("  [3] Go to Lib");
    System.out.println("  [4] Change User");
    System.out.println("  [5] Exit");
    while(option>5 || option < 1){
      System.out.print("Option: ");
      option = sc.nextInt();
    }
    return option;
  }

  public static void signUp(Library mainLib){  // creating an instance of user
    Scanner sc = new Scanner(System.in);
    // get the user credentials
    String name, username, password;
    System.out.println("Sign Up");
    System.out.print("  Name: ");
    name = sc.nextLine();
    System.out.print("  Username: ");
    username = sc.nextLine();
    System.out.print("  password: ");
    password = sc.nextLine();

    // instantiate a user object using the credentials
    User user = new User(name,username,password);
    avatar = user;
    user.setMembership(mainLib); // set the membership attribute to mainLib
    users[noOfUsers] = user; // put the instantiated user to the array of users
    noOfUsers ++; // increment the class attribute user by 1
  }

  public static void changeUser(){
    int i =0, newUser;
    Scanner sc = new Scanner(System.in);
    while(i<noOfUsers){
      System.out.println("[" + (i+1) + "]" + users[i].getName());
      i++;
    }
    System.out.println("New User: ");
    newUser = sc.nextInt();
    if(newUser-1 < noOfUsers){
        avatar = users[newUser-1];
        System.out.println(users[newUser-1].getName() + " is now active");
    }
    else{
      System.out.println("Errorrrrrr!");
    }

  }

}
