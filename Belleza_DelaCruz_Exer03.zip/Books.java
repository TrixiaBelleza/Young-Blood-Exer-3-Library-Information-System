package lib;
import java.util.Random;

public class Books{
  // attributes
  private static int idNum; // used for books id
  private String id; // id in hexadecimal
  private String title; // title of the book (used for searching/borrowing)
  private String author; // author of the book
  private int inventory; // remaining instance of  a book
  private String publication; // year of publication
  private String type; // type of book

  // constructor
  public Books(String title, String author, String publication, String type){
    Random r = new Random(); // used to randomize the inventory of the book
    this.id = Integer.toHexString(this.idNum++); // giving a hexadecimal id to the bool
    this.title = title;
    this.author = author;
    this.publication = publication;
    this.type = type;
    this.inventory = r.nextInt(6)+15; // randomizing the number of instance
  }

public String getType(){
    return this.type;
}

public String getTitle(){
  return this.title;
}

public int getInventory(){
  return this.inventory;
}

public void setInventory(int inventory){
  this.inventory = inventory;
}

public String getAuthor(){
  return this.author;
}

public String getPublication(){
  return this.publication;
}

public String getId(){
  return this.id;
}

public void setId(String id){
  this.id = id;
}

}
