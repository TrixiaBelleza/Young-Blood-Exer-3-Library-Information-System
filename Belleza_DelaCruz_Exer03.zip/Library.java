package lib;
import java.io.*;
import person.User;
import java.util.Scanner;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
public class Library{
  // attributes
  private String libName; //library name
  private static final int MAX_MEM = 10; //max members of user
  private static final int MAX_BOOKS = 20; //max books of user 
  private static int noOfBooks = 0; //counts number of books
  private static int noOfMembers = 0; //counts number of users 
  private User[] members; // array of library members
  private HashMap<String, ArrayList<Books>> bookmap;  // hash map with book title as the key and array of books with same title as the value
  // constructor
  public Library(String libName){
    this.libName = libName; 
    this.bookmap = new HashMap<String, ArrayList<Books>>();
    this.members = new User[MAX_MEM];
  }

  // methods
  public void libMenu(){
    int option = 0, checker = 0; //option -- choice sa menu
    String book; 
    Books borrowedbook; //instance of Books
    Scanner sc = new Scanner(System.in); 
	//Dashboard
    System.out.println("Library Menu");
    System.out.println("  [1] Add Book");
    System.out.println("  [2] Members");
    System.out.println("  [3] Load Books");
    System.out.println("  [4] Back");
    while(option>4 || option < 1){
      System.out.print("Option: ");
      option = sc.nextInt();
      switch(option){
        case 01: addBooks(); break;
        case 02: members(); break;
        case 03: loadLibrary(); break;
        case 04: System.out.println(" ");
        default: System.out.println("Invalid");
      }
    }
    }


  public void addBooks(){ // add books to shelves
    Scanner sc = new Scanner(System.in);
    String title, author, type, publication;
    // get the book credentials
    System.out.println("Add Books");
    System.out.print("  Book title: ");
    title = sc.nextLine(); //get title
    System.out.print("  Author: "); 
    author = sc.nextLine(); //get author 
    System.out.print("  Publication: ");
    publication = sc.nextLine(); //get publication
    System.out.print("  Type: ");
    type = sc.nextLine(); //get type
	
    // instantiate a book
    Books newbook = new Books(title, author, publication, type);

    loadBooks(newbook); //add books to shelves
  }


  public void loadBooks(Books newbook){ // add books to shelves
    if(this.bookmap.get(newbook.getTitle())== null){ //if walang nagmatch
      this.bookmap.put(newbook.getTitle(),new ArrayList<Books>()); //just put it in the hashmap and instantiate new arraylist of books
    }
    this.bookmap.get(newbook.getTitle()).add(newbook); //kunin yung title tapos i-add yung new book sa bookmap
    System.out.println(newbook.getTitle() + " is added to the library");
  }

  public Books borrowSystem(String toBorrow){ // returns the book the user wants to borrow
    Books togive;
    if(this.bookmap.get(toBorrow) == null){ //pag no match
        System.out.println(toBorrow + " is not in our library");
        return null; 
    }else{
      togive = this.bookmap.get(toBorrow).get((this.bookmap.get(toBorrow).size()) - 1);
      if(togive.getInventory() != 0){
        this.bookmap.get(toBorrow).remove(togive);
        togive.setInventory(togive.getInventory() -1);
        System.out.println(toBorrow + " was borrowed");
        return(togive);
      }else{
        System.out.println("Out of Stock");
        return null;
      }

    }

  }

  public void returnSystem(Books toreturn){ // gets the book the user borrowed
    if(this.bookmap.get(toreturn.getTitle()) == null){
      System.out.println("This book is not ours");
    }
    else{
      this.bookmap.get(toreturn.getTitle()).add(toreturn);
      System.out.println("Thank you for keeping our books safe");
    }
  }

  public void membershipSystem(User user){ // add a member
    members[noOfMembers] = user;
    noOfMembers++;
  }

  public void Inventory(User user){ // output the whole inventory of  the  library
    String username, password;
    int i = 1;
    Scanner sc = new Scanner(System.in);
    System.out.print("Username: ");
    username = sc.nextLine();
    System.out.print("Password: ");
    password = sc.nextLine();
    if(user.getuserName().equals(username) == true && user.getpassWord().equals(password) == true){
      // traverse the hash map print every value
      for(String key : bookmap.keySet()){
        System.out.println("  [" + i + "]" + " " + key);
        i++;
      }
    }
    else{
      System.out.println("Error!!!!");
    }
  }

  public void members(){
    int i=0;
    while(i<noOfMembers){
      System.out.println("  ["+i+"]" + " " +members[i].getuserName());
      i++;
    }
  }

  public void saveLibrary(){
		try{
      File saveData = new File("Data.csv"); //open file Data.csv
			String delimiter = ","; //separates values
			BufferedWriter writer = new BufferedWriter(new FileWriter(saveData));
			for(String key: this.bookmap.keySet()){  //for every key in bookmap 
				for(Books value: this.bookmap.get(key)){ //for every value in bookmap's key
					//write
					writer.write(this.bookmap.get(value.getTitle())+ delimiter + this.bookmap.get(value.getAuthor()) + delimiter + this.bookmap.get(value.getPublication()) + delimiter + this.bookmap.get(value.getType())+delimiter+this.bookmap.get(value.getId()) +"\n" );
				}
			}
			writer.close();
		}
		catch( Exception e){
      System.out.println("Fail to save data.");
      e.printStackTrace();
		}
	}

  public void loadLibrary(){
		try{
			File saveData = new File("Data.csv"); 
			BufferedReader reader = new BufferedReader(new FileReader(saveData));
			String line;
			String delimiter = ",";
			Books bookToLoad = null; 

			while((line = reader.readLine()) != null){ //while di pa end of the line
				String[] bookAttributes = line.split(delimiter); //i-store sa list yung mga comma separated values. One index for each value
				bookToLoad = new Books(bookAttributes[0], bookAttributes[1],bookAttributes[2],bookAttributes[3] ); //instantiate books 
				bookToLoad.setId(bookAttributes[4]); //ID 
				this.loadBooks(bookToLoad); //update the hashmap
			}reader.close();
		}
		catch(Exception e){
			System.out.println("Failed to load data");
      e.printStackTrace();
		}
	}

}
