package person;
import java.io.*;
import lib.Books;
import lib.Library;
import java.util.Scanner;

public class User{
  // attributes
  private static final int MAX_VALUE = 10;
  private static int noOfborrowed = 0;
  private String name; // name of user
  private String userName;
  private String passWord;
  private Books[] borrowed; // list of borrowed books
  private Library membership;

  // constructor
  public User(String name, String userName, String password){
    this.name = name;
    this.userName = userName;
    this.passWord = password;
    this.borrowed = new Books[MAX_VALUE]; // instantiating an array of books
  }

  // methods
  private void borrowBook(){ // borrow a book
    String book;
    Books borrowedbook;
    Scanner sc = new Scanner(System.in);
    System.out.print("Book title:");
    book = sc.nextLine(); // get the title of the book to be borrowed
    borrowedbook = this.membership.borrowSystem(book); //  get the book from the library and put the book to the array of borrowed books
    if(borrowedbook != null){
    borrowed[noOfborrowed] = borrowedbook;
    noOfborrowed ++;
    }
  }

  private void returnBook(){ // return a borrowed book
    int i=0, checker=0;
    String book;
    Scanner sc = new Scanner(System.in);
    System.out.print("Book title:");
    book = sc.nextLine(); // get the title of the book to be returned
    while(i<noOfborrowed){ // search array of borrowed books if there is a book with the said title
      if(borrowed[i].getTitle().equals(book)){
        this.membership.returnSystem(borrowed[i]); // return the book by calling the library function returnSystem
        while(i < noOfborrowed){ // adjust the array of borrowed books
          borrowed[i] = borrowed[i++];
        }
        borrowed[i] = null; // set the last index to null
        noOfborrowed--; // decrement the number of borrowed books
        checker = 1; // set checker to 1
         break;
      }
      i++;
    }
    if(checker != 1){ // if the book was  not in the array of borrowed books
        System.out.println(book + " not found");
    }
  }

  public void userMenu(){
    int option = 0, checker = 0;
    String book;
    Books borrowedbook;
    Scanner sc = new Scanner(System.in);
    System.out.println("User Menu");
    System.out.println("  [1] Go to Lib System");
    System.out.println("  [2] Borrow a Book");
    System.out.println("  [3] Return Book");
    System.out.println("  [4] Back");
    while(option>4 || option < 1){
      System.out.print("Option: ");
      option = sc.nextInt();
      switch(option){
        case 01: this.membership.Inventory(this); break;
        case 02: borrowBook(); break;
        case 03: returnBook(); break;
        case 04: System.out.println(" ");break;
        default: System.out.println("Invalid");
      }
    }
  }

  public void setMembership(Library membership){
    this.membership = membership;
    this.membership.membershipSystem(this);
  }

  public String getuserName(){
    return this.userName;
  }
  public String getpassWord(){
    return this.passWord;
  }
  public String getName(){
    return this.name;
  }

}
